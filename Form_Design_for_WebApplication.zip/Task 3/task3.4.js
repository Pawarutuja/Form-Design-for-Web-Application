const otpInputs = document.querySelectorAll('.otp-inputs input');
const resendButton = document.querySelector('.resend-btn');
const countdownElement = document.getElementById('countdown');
let countdown;

// Auto-tab functionality
otpInputs.forEach((input, index) => {
    input.addEventListener('input', () => {
        if (input.value.length === 1 && index < otpInputs.length - 1) {
            otpInputs[index + 1].focus();
        }
    });

    // Backspace functionality
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !input.value && index > 0) {
            otpInputs[index - 1].focus();
        }
    });
});

// Start countdown
function startCountdown(duration) {
    let timer = duration, minutes, seconds;
    countdown = setInterval(() => {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);
        countdownElement.textContent = `${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
        if (--timer < 0) {
            clearInterval(countdown);
            document.querySelector('.verify-btn').disabled = true;
            resendButton.disabled = false;
            countdownElement.textContent = 'OTP expired';
        }
    }, 1000);
}

// Start a 2-minute countdown
startCountdown(120);

// Resend OTP logic
resendButton.addEventListener('click', () => {
    // Resend OTP code here
    startCountdown(120); // Restart countdown
    resendButton.disabled = true;
    document.querySelector('.verify-btn').disabled = false;
});
document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;

    // Toggle dark mode
    themeToggle.addEventListener('change', () => {
        body.classList.toggle('dark-theme');

        // Optional: Save the user's theme preference in local storage
        if (body.classList.contains('dark-theme')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
    });

    // Check for saved theme preference on page load
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        body.classList.add('dark-theme');
        themeToggle.checked = true;
    }
});
