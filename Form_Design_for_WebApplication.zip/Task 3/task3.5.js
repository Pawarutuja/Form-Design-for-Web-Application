document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;
    const changePasswordForm = document.getElementById('changePasswordForm');
    const currentPassword = document.getElementById('currentPassword');
    const newPassword = document.getElementById('newPassword');
    const confirmPassword = document.getElementById('confirmPassword');
    const passwordStrength = document.getElementById('passwordStrength');
    const feedback = document.getElementById('feedback');
    const showPasswords = document.getElementById('showPasswords');

    // Toggle dark mode
    themeToggle.addEventListener('change', () => {
        body.classList.toggle('dark-theme');
        localStorage.setItem('theme', body.classList.contains('dark-theme') ? 'dark' : 'light');
    });

    // Load theme preference
    if (localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-theme');
        themeToggle.checked = true;
    }

    // Show/hide passwords
    showPasswords.addEventListener('change', () => {
        const type = showPasswords.checked ? 'text' : 'password';
        currentPassword.type = type;
        newPassword.type = type;
        confirmPassword.type = type;
    });

    // Password strength meter
    newPassword.addEventListener('input', () => {
        const strength = checkPasswordStrength(newPassword.value);
        passwordStrength.style.width = `${strength.percentage}%`;
        passwordStrength.style.backgroundColor = strength.color;
    });

    // Form validation
    changePasswordForm.addEventListener('submit', (event) => {
        event.preventDefault();
        feedback.textContent = '';

        if (!newPassword.value || !confirmPassword.value || !currentPassword.value) {
            feedback.textContent = 'All fields are required.';
            return;
        }

        if (newPassword.value !== confirmPassword.value) {
            feedback.textContent = 'New password and confirm password do not match.';
            return;
        }

        feedback.textContent = 'Password changed successfully!';
        feedback.style.color = 'green';
    });

    function checkPasswordStrength(password) {
        let percentage = 0;
        let color = '#f44336'; // Weak

        if (password.length > 8) {
            percentage = 100;
            color = '#04AA6D'; // Strong
        } else if (password.length > 5) {
            percentage = 50;
            color = '#ff9800'; // Medium
        }

        return { percentage, color };
    }
});
