// Phone number validation pattern
const phonePattern = /^[0-9]{10}$/;

// Preview profile picture function
function previewProfilePicture() {
    const fileInput = document.getElementById('profilePicture');
    const preview = document.getElementById('picturePreview');
    const file = fileInput.files[0];

    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    } else {
        preview.src = '#';
        preview.style.display = 'none';
    }
}

// Reset form to default values
function resetForm() {
    document.getElementById('profileForm').reset();
    document.getElementById('picturePreview').style.display = 'none';
}

// Form submission handler with validation
document.getElementById('profileForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevent form submission

    const phoneNumber = document.getElementById('phoneNumber').value;
    const fileInput = document.getElementById('profilePicture');
    const file = fileInput.files[0];

    // Validate phone number
    if (!phonePattern.test(phoneNumber)) {
        alert('Please enter a valid 10-digit phone number.');
        return;
    }

    // Validate profile picture (optional, max size 2MB)
    if (file && file.size > 2 * 1024 * 1024) {
        alert('Profile picture must be less than 2MB.');
        return;
    }

    // If validation passes
    alert('Profile saved successfully!');
});

document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;

    // Toggle dark mode
    themeToggle.addEventListener('change', () => {
        body.classList.toggle('dark-theme');

        // Optional: Save the user's theme preference in local storage
        if (body.classList.contains('dark-theme')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
    });

    // Check for saved theme preference on page load
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        body.classList.add('dark-theme');
        themeToggle.checked = true;
    }
});
